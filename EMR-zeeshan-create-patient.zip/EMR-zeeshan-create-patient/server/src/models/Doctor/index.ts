export * from "./doctorSchema";
export * from "./doctorDAL";