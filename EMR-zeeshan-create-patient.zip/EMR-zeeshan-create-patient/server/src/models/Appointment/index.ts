export * from "./appointmentSchema";
export * from "./appointmentDAL"; 