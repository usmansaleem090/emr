// Re-export ClinicsPage from Clinic Management folder
export { default } from './Clinic Management/ClinicsPage'; 
