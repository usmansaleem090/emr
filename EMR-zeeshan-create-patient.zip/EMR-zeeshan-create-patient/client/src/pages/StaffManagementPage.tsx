import React, { useState, useEffect } from "react";
import { Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/UI/card";
import { Button } from "@/components/UI/button";
import { Input } from "@/components/UI/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/UI/table";
import { Badge } from "@/components/UI/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/UI/alert-dialog";
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Calendar,
  UserPlus,
  Shield,
  Clock,
  Building2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { api } from '@/utils/apiClient';
import { LoadingSpinner } from '@/components/UI/LoadingSpinner';
import { useAppSelector } from '@/redux/hooks';
import DoctorScheduleModalNew from "@/components/doctors/DoctorScheduleModalNew";

interface StaffMember {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  employeeId?: string;
  position: string;
  department: string;
  employmentStatus: string;
  startDate: string;
  endDate?: string;
  salary?: string;
  hourlyRate?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  address?: string;
  dateOfBirth?: string;
  gender?: string;
  notes?: string;
  status: string;
  userId: number;
  clinicId: number;
  supervisorId?: number;
  createdAt: string;
  updatedAt: string;
  clinicName?: string;
}

const StaffManagementPage: React.FC = () => {
  const { toast } = useToast();
  const user = useAppSelector((state) => state.auth.user);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [filteredStaff, setFilteredStaff] = useState<StaffMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);

  // Load staff data
  const loadStaff = async () => {
    try {
      setIsLoading(true);
      const response = await api.get(`/api/clinic-staff${user?.clinicId ? `?clinic_id=${user.clinicId}` : ''}`);
      console.log('Raw staff API response:', response);
      console.log('Response data:', response.data);
      console.log('Response data type:', typeof response.data);
      
      // Handle different response structures with more robust checking
      let staffData = [];
      
      if (response?.data) {
        // Try direct data access first (most common case)
        if (response.data.data && Array.isArray(response.data.data)) {
          staffData = response.data.data;
        } 
        // Fallback to direct array if that's the structure
        else if (Array.isArray(response.data)) {
          staffData = response.data;
        } 
        // Handle empty or null data
        else {
          console.warn('Response data is not an array:', response.data);
          staffData = [];
        }
      } else {
        console.warn('No response data received');
        staffData = [];
      }
      
      console.log('Final staff data to set:', staffData);
      console.log('Staff data length:', staffData.length);
      
      setStaff(staffData);
      setFilteredStaff(staffData);
    } catch (error: any) {
      console.error('Failed to load staff:', error);
      toast({
        title: "Error",
        description: error.response?.data?.message || error.message || "Failed to load staff members.",
        variant: "destructive",
      });
      // Set empty arrays on error to prevent undefined issues
      setStaff([]);
      setFilteredStaff([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Schedule modal handler
  const handleViewSchedule = (staffMember: StaffMember) => {
    setSelectedStaff(staffMember);
    setScheduleModalOpen(true);
  };

  // Delete staff member
  const handleDelete = async (staffMember: StaffMember) => {
    try {
      setDeleteLoading(true);
      await api.delete(`/api/clinic-staff/${staffMember.id}`);
      toast({
        title: "Success",
        description: "Staff member deleted successfully.",
      });
      await loadStaff(); // Reload the staff list
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete staff member.",
        variant: "destructive",
      });
    } finally {
      setDeleteLoading(false);
    }
  };

  // Search functionality
  useEffect(() => {
    if (!searchTerm) {
      setFilteredStaff(staff);
    } else {
      const filtered = staff.filter(staffMember =>
        `${staffMember.firstName || ''} ${staffMember.lastName || ''}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        staffMember.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        staffMember.employeeId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        staffMember.position?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        staffMember.department?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredStaff(filtered);
    }
  }, [searchTerm, staff]);

  useEffect(() => {
    loadStaff();
  }, [user?.clinicId]);

  // Utility functions
  const formatDate = (dateString: string) => {
    if (!dateString) return '-';
    try {
      return new Date(dateString).toLocaleDateString();
    } catch {
      return dateString;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-gray-100 text-gray-800',
      terminated: 'bg-red-100 text-red-800',
    };
    
    return (
      <Badge className={statusColors[status as keyof typeof statusColors] || statusColors.inactive}>
        {status}
      </Badge>
    );
  };

  const getPositionBadge = (position: string) => {
    const positionColors = {
      'Staff': 'bg-blue-100 text-blue-800',
      'Cleaner': 'bg-purple-100 text-purple-800',
      'Receptionist': 'bg-green-100 text-green-800',
      'MA': 'bg-orange-100 text-orange-800',
      'Nurse': 'bg-pink-100 text-pink-800',
      'Manager': 'bg-indigo-100 text-indigo-800',
      'Administrator': 'bg-red-100 text-red-800',
    };
    
    return (
      <Badge className={positionColors[position as keyof typeof positionColors] || 'bg-gray-100 text-gray-800'}>
        {position}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
            <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Staff Management</h1>
          <p className="mt-2 text-gray-600">
            Manage clinic staff members and their information
          </p>
        </div>
        <Link href="/staff/add">
          <Button className="bg-blue-600 hover:bg-blue-700">
            <UserPlus className="w-4 h-4 mr-2" />
            Add Staff Member
          </Button>
        </Link>
      </div>

      {/* Statistics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{staff.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <Users className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {staff.filter(s => s.status === 'active').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Full-Time</CardTitle>
            <Clock className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {staff.filter(s => s.employmentStatus === 'Full-time').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New This Month</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {staff.filter(s => {
                if (!s.createdAt) return false;
                const createdDate = new Date(s.createdAt);
                const now = new Date();
                const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
                return createdDate >= thisMonth;
              }).length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search Staff</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by name, email, employee ID, position, or department..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Staff Table */}
      <Card>
        <CardHeader> 
          <CardTitle>All Staff Members</CardTitle>
          <CardDescription>
            {filteredStaff.length > 0 
              ? `${filteredStaff.length} staff member${filteredStaff.length === 1 ? '' : 's'} found`
              : searchTerm ? 'No staff members match your search' : 'No staff members found'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredStaff.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">
                {searchTerm ? 'No staff members match your search criteria.' : 'No staff members found.'}
              </p>
              {!searchTerm && (
                <Link href="/staff/add">
                  <Button>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Add Your First Staff Member
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredStaff.map((staffMember) => (
                <div
                  key={staffMember.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Users className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">
                        {staffMember.firstName && staffMember.lastName
                          ? `${staffMember.firstName} ${staffMember.lastName}`
                          : staffMember.email?.split("@")[0]}
                      </div>
                      <div className="text-sm text-gray-600">
                        {getPositionBadge(staffMember.position)} • {staffMember.department}
                      </div>
                      <div className="text-sm text-gray-500">
                        {staffMember.email} • {staffMember.phone || "No phone"}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        staffMember.status === "active"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {staffMember.status}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewSchedule(staffMember)}
                      className="flex items-center gap-1"
                    >
                      <Calendar className="h-3 w-3" />
                      Schedule
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      asChild
                    >
                      <Link href={`/staff/${staffMember.id}/edit`}>
                        <Edit2 className="h-4 w-4" />
                        Edit
                      </Link>
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          disabled={deleteLoading}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Staff Member</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete {staffMember.firstName || ''} {staffMember.lastName || ''}? 
                            This action cannot be undone and will remove all staff records and their user account.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(staffMember)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    {/* Staff Schedule Modal */}
    {selectedStaff && (
      <DoctorScheduleModalNew
        isOpen={scheduleModalOpen}
        onClose={() => {
          setScheduleModalOpen(false);
          setSelectedStaff(null);
        }}
        type={'staff'}
        clinicId={user?.clinicId || 0}
        doctorId={selectedStaff.userId || 0}
        doctorName={selectedStaff.firstName && selectedStaff.lastName ? `${selectedStaff.firstName} ${selectedStaff.lastName}` : selectedStaff.email?.split("@")[0]}
      />
    )}
  </div>
  );
};

export default StaffManagementPage;