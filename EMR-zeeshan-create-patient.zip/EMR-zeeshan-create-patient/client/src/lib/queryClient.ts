// Legacy file - now uses main apiClient
// Import the main API client for all axios operations
export { api as apiRequest, api, apiClient } from '../utils/apiClient';